package com.plantix.features.home;


public interface HomeNavigation {


}
