package com.plantix.features.splash;


import com.plantix.data.base.BaseViewModel;

public class SplashViewModel extends BaseViewModel<SplashNavigator> {

}
