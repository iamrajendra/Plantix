package com.plantix.features.splash;

interface SplashNavigator {
}
